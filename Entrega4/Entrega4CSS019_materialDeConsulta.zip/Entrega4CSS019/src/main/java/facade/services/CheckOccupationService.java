package facade.services;

import business.handlers.CheckOcupationHandler;
import facade.exceptions.ApplicationException;
import facade.wrappers.Record;

/**
 * A service that offers operations to check the occupation of a space.
 * The purpose of this class is to provide access to the business layer, hiding its
 * implementation from the clients
 *
 */
public class CheckOccupationService {

	/**
	 * The business object facade that handles the use case check occupation
	 */
	private CheckOcupationHandler checkOccupationHandler;
	
	/**
	 * Constructs a check occupation service given the check occupation handler
	 * @param checkOccupationHandler The check occupation handler
	 */
	public CheckOccupationService(CheckOcupationHandler checkOccupationHandler) {
		this.checkOccupationHandler = checkOccupationHandler;
	}
	
	/**
	 * Given a space name, checks if space exists, and returns list of wrappers for
	 * its occupation records, for the period between startDate and endDate
	 * @param spaceName The name of the space
	 * @param startDate String representing the starting date of the period to check
	 * @param endDate String representing the end date of the period to check
	 * @return A list of wrappers for the space occupation records
	 * @throws ApplicationException If there was an error checking the space's availability in the given interval
	 */
	public Iterable<Record> checkUseOfSpace(String spaceName, String startDate, String endDate) throws ApplicationException {
		return checkOccupationHandler.checkUseOfSpace(spaceName, startDate, endDate);
	}
}
