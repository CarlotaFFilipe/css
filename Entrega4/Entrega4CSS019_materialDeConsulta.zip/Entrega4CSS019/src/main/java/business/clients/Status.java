package business.clients;

public enum Status {
	BRONZE, SILVER, GOLD

}
