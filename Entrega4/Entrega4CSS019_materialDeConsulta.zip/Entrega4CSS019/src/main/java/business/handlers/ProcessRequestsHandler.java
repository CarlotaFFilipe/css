package business.handlers;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;

import business.activities.Activity;
import business.clients.Client;
import business.clients.Club;
import business.requests.RequestCatalog;
import business.requests.ReservationRequest;
import business.requests.exceptions.InvalidRequestException;
import business.reservations.ReservationCatalog;
import business.spaces.Space;
import business.spaces.SpaceCatalog;
import business.spaces.exceptions.UnavailableSpaceException;
import business.sports.SportCatalog;
import business.sports.exceptions.InvalidSportException;
import facade.exceptions.ApplicationException;
import facade.wrappers.Request;

/**
 * Handles the process requests use case
 *
 */
public class ProcessRequestsHandler {
	
	/**
	 * Entity manager factory for accessing the persistence service 
	 */
	private EntityManagerFactory emf;
	
	/**
	 * Creates a handler for the process requests use case given
	 * the application's entity manager factory
	 * @param emf The entity manager factory of the application
	 */
	public ProcessRequestsHandler(EntityManagerFactory emf) {
		this.emf = emf;
	}
	
	/**
	 * Starts processing requests and returns a list with the names of all existing sports
	 * @return A list with the names of all existing sports
	 * @throws ApplicationException When there is an error retrieving the sports from the database
	 */
	public Iterable<String> startProcessing() throws ApplicationException {
		EntityManager em = emf.createEntityManager();
		SportCatalog sportCatalog = new SportCatalog(em);
		try {
			em.getTransaction().begin();
			Iterable<String> sports = sportCatalog.getSports();
			em.getTransaction().commit();
			return sports;
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new ApplicationException("Error fetching sports.", e);
		} finally {
			em.close();
		}
	}
	
	/**
	 * Receives a sport and a request type and checks that:
	 * 			- the sport is valid
	 * 			- the client type is valid
	 * and returns an iterable of all 'wrapped' requests with given sport and type.
	 * @param sport The name of the sport
	 * @param type The client type
	 * @return A list of all requests with the given sport and client type
	 * @throws ApplicationException When the given sport or client type are invalid or when there's 
	 * an error from the database
	 */
	public Iterable<Request> filterRequests(String sport, String type) throws ApplicationException {
		EntityManager em = emf.createEntityManager();
		SportCatalog sportCatalog = new SportCatalog(em);
		RequestCatalog requestCatalog = new RequestCatalog(em);
		
		try {
			em.getTransaction().begin();
			sportCatalog.getSportByName(sport);
			if (!requestCatalog.isValidType(type)) {
				throw new InvalidRequestException("Type " + type + " is not a valid request type.");
			}
			Iterable<Request> requests = requestCatalog.getAllRequestsBy(type, sport);
			em.getTransaction().commit();
			return requests;
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new ApplicationException("Error filtering sports.", e);
		}
	}
	
	/**
	 * Receives a request id and the name of a space and checks that:
	 * 			- the request id represents an existing pending request
	 * 			- the space with the given name exists
	 * 			- the space allows for the practice of the requested sport
	 * 			- the space is free in the requested period
	 * Also does the following:
	 * 			- creates the occupation records for the requested activity
	 *          - updates the user's status if it is a club
	 *          - creates a reservation for the given space and activity
	 *          - persists the reservation & the occupation records
	 *         
	 * @param requestId The request's id
	 * @param spaceName The name of the space
	 * @throws ApplicationException //if there was an error selecting a request with the given number and space
	 */
	public void chooseRequest(int requestId, String spaceName) throws ApplicationException {
		
		EntityManager em = emf.createEntityManager();
		
		// the catalogs
		RequestCatalog requestCatalog = new RequestCatalog(em);
		SpaceCatalog spaceCatalog = new SpaceCatalog(em);
		ReservationCatalog resCatalog = new ReservationCatalog(em);
		

		try {
			// begin transaction
			em.getTransaction().begin();
			
			// validate request id
			ReservationRequest request = requestCatalog.getRequest(requestId);
			
			// check that request is pending
			if (!request.isPending()) {
				throw new InvalidRequestException("Request " + requestId + " is already closed.");
			}
			
			// validate space name
			Space space = spaceCatalog.getSpaceByName(spaceName);
			
			// check if sport is allowed
			String sportName = request.getSport();
			if (!space.allowsSport(sportName)) {
				throw new InvalidSportException("Sport " + sportName + " not allowed in this space.");
			}
			
			// check if space is free in period
			if (!space.isFree(request.getPeriod(), request.getType())) {
				throw new UnavailableSpaceException("Space " + spaceName + " is unavailable in the requested period.");
			}
			
			// create records & persist them
			Activity activity = request.getActivity();
			space.createRecords(activity, request.getType());
			em.merge(space);
			
			// update club status
			Client client = activity.getClient();
			if (client instanceof Club) {
				Club club = (Club) client;
				club.addHours(request.getReservedHours());
				club.updateStatus();
				em.merge(club);
			}
		
			// close request
			request.close();
			em.merge(request);
			
			// create reservation & persist it
			resCatalog.addReservation(request, space);
			
			// end transaction
			em.getTransaction().commit();
			
		} catch (Exception e) {
			if (em.getTransaction().isActive()) {
				em.getTransaction().rollback();
			}
			throw new ApplicationException("Error choosing request.", e);
		}	
	}

}
