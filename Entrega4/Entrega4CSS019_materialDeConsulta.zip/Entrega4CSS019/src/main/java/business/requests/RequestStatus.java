package business.requests;

public enum RequestStatus {
	CLOSED, OPEN
}
