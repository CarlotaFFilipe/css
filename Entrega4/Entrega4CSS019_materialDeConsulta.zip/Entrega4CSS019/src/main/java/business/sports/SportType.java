package business.sports;

public enum SportType {
	
	COLECTIVAS, RAQUETES, AQUATICAS

}
